# DA-09 Power BI Dashboard Build Guide
## Use the cleaned CSV
File: `data/cleaned/Superstore_Cleaned.csv`
1. Open Power BI Desktop.
2. Home > Get data > Text/CSV. Select the cleaned CSV.
3. Confirm dates are Date type; Sales/Profit are Decimal number; Quantity is Whole number; Discount is Decimal number; IDs are Text.
4. Select Load.
5. Create measures (Modeling > New measure):
```DAX
Total Sales = SUM('Superstore_Cleaned'[Sales])
Total Profit = SUM('Superstore_Cleaned'[Profit])
Total Quantity = SUM('Superstore_Cleaned'[Quantity])
Distinct Orders = DISTINCTCOUNT('Superstore_Cleaned'[Order ID])
Profit Margin = DIVIDE([Total Profit], [Total Sales])
Average Discount = AVERAGE('Superstore_Cleaned'[Discount])
Loss-Making Rows = CALCULATE(COUNTROWS('Superstore_Cleaned'), 'Superstore_Cleaned'[Profit] < 0)
```
If Power BI names the table differently, replace `'Superstore_Cleaned'` with the actual table name.
## Recommended single-page layout
Top row KPI cards: Total Sales, Total Profit, Profit Margin, Distinct Orders, Average Discount.
Visual 1: clustered column chart — Axis `Discount Band`, Values `Total Sales` and `Total Profit`.
Visual 2: column chart — Axis `Discount Band`, Values `Profit Margin`.
Visual 3: bar chart — Axis `Sub-Category`, Values `Total Profit`, sorted ascending.
Visual 4: bar chart — Axis `Region`, Values `Total Profit`.
Visual 5: clustered bar chart — Axis `Category`, Values `Total Sales` and `Total Profit`.
Slicers: Region, Category, Segment, Order Date.
Use clear titles, currency formatting for sales/profit, percentage formatting for margin/discount, and avoid claiming causation.
Save as `DA09_Store_Profitability_Dashboard.pbix`.
