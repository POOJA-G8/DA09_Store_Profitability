# DA-09 Submission Pack — Pooja G
## Contents
- `data/raw/Sample - Superstore.csv`: untouched copy of uploaded original.
- `data/cleaned/Superstore_Cleaned.csv`: cleaned export, all 9,994 rows retained, original 21 columns plus derived Discount Band.
- `excel/DA09_Data_Inspection_and_Summaries.xlsx`: cleaned data, dictionary, log and summaries.
- `sql/DA09_Analysis_Queries.sql`: 10 MySQL queries including grouping, subquery, CTE/window function and a valid join to an observed product dimension.
- `python/DA09_Superstore_EDA.ipynb`: EDA notebook with 8 charts and written observations.
- `reports/DA09_Problem_Statement.docx`: problem statement.
- `reports/DA09_Insights_and_Recommendations.docx`: findings and recommendations.
- `reports/Data_Dictionary.csv` and `reports/Data_Cleaning_Log.csv`.
- `presentation/DA09_5_Minute_Presentation.pptx`: five-minute deck.
- `dashboard/PowerBI_Dashboard_Instructions.md`: steps and DAX measures for Power BI.
- `charts/`: chart images used in report/deck and helpful for the notebook.
## Verified metrics
Rows: 9,994; columns in original: 21; sales: $2,297,200.86; profit: $286,397.02; margin: 12.47%; quantity: 37,873; distinct orders: 5,009; distinct customers: 793; average discount: 15.62%.
## Important source/licence note
Source page: https://www.kaggle.com/datasets/vivek468/superstore-dataset-final
The CSV file does not contain licence metadata, and the current licence has not been independently verified in this pack. Open the Kaggle page and record the exact licence displayed before claiming redistribution rights. Keep the source attribution.
## Last-minute workflow
1. Verify licence on Kaggle.
2. Open the Jupyter notebook and run cells top-to-bottom; adjust DATA_PATH if needed.
3. Import cleaned CSV into phpMyAdmin table `superstore_cleaned`; run SQL script queries in order. If CTE/window functions fail, check MySQL version (MySQL 8+ required for Q8).
4. Build and save the Power BI `.pbix` using the guide.
5. Open and proofread Word documents and PowerPoint. Do not present the dashboard as completed until the `.pbix` is saved.
6. Submit only files you have opened and checked.
