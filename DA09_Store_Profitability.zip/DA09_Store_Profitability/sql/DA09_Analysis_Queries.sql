-- DA-09 Store Profitability & Discount Impact
-- MySQL / XAMPP phpMyAdmin
-- Import data/cleaned/superstore.csv into table: superstore.
-- If using phpMyAdmin, ensure Discount Band column is imported as VARCHAR.
-- Profit margin is SUM(Profit)/SUM(Sales), not average row margin.

-- Q1. Overall KPIs
SELECT COUNT(*) AS line_rows, COUNT(DISTINCT `Order ID`) AS distinct_orders,
       COUNT(DISTINCT `Customer ID`) AS distinct_customers,
       SUM(Sales) AS total_sales, SUM(Profit) AS total_profit,
       SUM(Quantity) AS total_quantity,
       SUM(Profit)/NULLIF(SUM(Sales),0) AS overall_profit_margin,
       AVG(Discount) AS average_discount
FROM superstore;

-- Q2. Sales, profit and margin by discount band
SELECT `Discount Band`, COUNT(*) AS line_rows, SUM(Sales) AS sales,
       SUM(Profit) AS profit, SUM(Profit)/NULLIF(SUM(Sales),0) AS profit_margin,
       AVG(Discount) AS avg_discount, COUNT(DISTINCT `Order ID`) AS orders
FROM superstore
GROUP BY `Discount Band`
ORDER BY MIN(Discount);

-- Q3. Category profitability
SELECT Category, SUM(Sales) AS sales, SUM(Profit) AS profit,
       SUM(Profit)/NULLIF(SUM(Sales),0) AS profit_margin,
       AVG(Discount) AS avg_discount
FROM superstore
GROUP BY Category ORDER BY profit DESC;

-- Q4. Subcategories that lose money (GROUP BY + HAVING)
SELECT Category, `Sub-Category`, SUM(Sales) AS sales, SUM(Profit) AS profit,
       SUM(Profit)/NULLIF(SUM(Sales),0) AS profit_margin,
       AVG(Discount) AS avg_discount
FROM superstore
GROUP BY Category, `Sub-Category`
HAVING SUM(Profit) < 0
ORDER BY profit ASC;

-- Q5. Regional profitability
SELECT Region, SUM(Sales) AS sales, SUM(Profit) AS profit,
       SUM(Profit)/NULLIF(SUM(Sales),0) AS profit_margin,
       AVG(Discount) AS avg_discount
FROM superstore
GROUP BY Region ORDER BY profit DESC;

-- Q6. Customer segment profitability
SELECT Segment, COUNT(DISTINCT `Customer ID`) AS customers,
       SUM(Sales) AS sales, SUM(Profit) AS profit,
       SUM(Profit)/NULLIF(SUM(Sales),0) AS profit_margin
FROM superstore
GROUP BY Segment ORDER BY profit DESC;

-- Q7. Products with the largest total losses (subquery)
SELECT p.`Product ID`, p.`Product Name`, p.sales, p.profit, p.avg_discount
FROM (
  SELECT `Product ID`, `Product Name`, SUM(Sales) AS sales,
         SUM(Profit) AS profit, AVG(Discount) AS avg_discount
  FROM superstore
  GROUP BY `Product ID`, `Product Name`
) AS p
WHERE p.profit < 0
ORDER BY p.profit ASC
LIMIT 10;

-- Q8. Window function: rank subcategories by profit within each category
WITH subcat AS (
  SELECT Category, `Sub-Category`, SUM(Sales) AS sales, SUM(Profit) AS profit
  FROM superstore
  GROUP BY Category, `Sub-Category`
)
SELECT Category, `Sub-Category`, sales, profit,
       RANK() OVER (PARTITION BY Category ORDER BY profit DESC) AS profit_rank_in_category
FROM subcat
ORDER BY Category, profit_rank_in_category;

-- Q9. Join: create a product dimension from observed data and join it to line items.
-- This does not invent products; it selects distinct observed Product ID/name/category values.
CREATE OR REPLACE VIEW dim_product AS
SELECT DISTINCT `Product ID`, `Product Name`, Category, `Sub-Category`
FROM superstore;
SELECT p.Category, p.`Sub-Category`, SUM(s.Sales) AS sales, SUM(s.Profit) AS profit
FROM superstore s
JOIN dim_product p ON s.`Product ID` = p.`Product ID`
GROUP BY p.Category, p.`Sub-Category`
ORDER BY profit ASC;

-- Q10. Discount vs profit association (not causal proof)
SELECT Discount, COUNT(*) AS line_rows, SUM(Sales) AS sales, SUM(Profit) AS profit,
       SUM(Profit)/NULLIF(SUM(Sales),0) AS profit_margin,
       AVG(Quantity) AS avg_quantity
FROM superstore
GROUP BY Discount
ORDER BY Discount;
